const express = require('express');
const morgan = require('morgan');
const { MongoClient } = require('mongodb');
const path = require('node:path');

const app = express();
const hostname = 'localhost';
const port = 3001;

const dboper = require('./operations.js');

const uri = 'mongodb://localhost:27017/';
const dbname = 'lab';

(async function() {

  const client = new MongoClient(uri);

  try {
    await client.connect();

    console.log('Connected to MongoDB!');

    const db = client.db(dbname);

    let doc = { name: "Motor", status: "Not defined" };

    dboper.insertDocument(db, doc, "device", (result) => {
      console.log("Insert Document:\n", result.insertedCount);
    });

    app.post('/SysON', (_req, res) => {
      doc = { name: "Motor", status: "ON" };
      const update = { name: "Motor" };
      dboper.updateDocument(db, update, doc, "device", (result) => {console.log(result)});
      console.log("Inserted Document\n");
      res.status(301).send("System is now On")
    });

    app.post('/SysOFF', (_req, res) => {
      doc = { name: "Motor", status: "OFF" };
      const update = { name: "Motor" };
      dboper.updateDocument(db, update, doc, 'device', (result) => { console.log(result.insertedCount()) });
      res.status(301).send("System is now OFF"); 
    })
  } catch (err) {
    console.error('Error connecting to MongoDB:', err);
  }
})();

app.use(morgan('dev'));

const publicDir = path.join(__dirname, '../public');
app.use(express.static(publicDir));

// Route to handle URL redirection or serve the same page
app.get('/*', (_req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

// Start the server
app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}`);
});

